sudo docker stop jetbot_camera 
sudo docker rm jetbot_camera

sudo docker stop jetbot_jupyter 
sudo docker rm jetbot_jupyter

sudo docker stop jetbot_display 
sudo docker rm jetbot_display
