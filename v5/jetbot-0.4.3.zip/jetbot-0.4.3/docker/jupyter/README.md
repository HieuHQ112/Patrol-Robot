# Jupyter Container

This container includes

* A launch script to run jupyter lab at the specified working directory

#### Build

```bash
cd docker/jupyter
./build.sh
```

#### Run

```bash
cd docker/jupyter
./enable.sh $HOME
```
