#!/bin/bash

# Re-enable GUI
sudo systemctl set-default graphical.target


